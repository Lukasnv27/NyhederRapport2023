function addFavorite1 () { 
    let favorite = document.getElementById("favoriteBtn1");
    favorite.style.backgroundColor = "red";
    favorite.style.color = "white";
    favorite.innerHTML = "Favorited";
} // Styler knappen til at blive rød og skrive 
// "Favorited" når den bliver trykket på

function addFavorite2 () {
    let favorite = document.getElementById("favoriteBtn2");
    favorite.style.backgroundColor = "red";
    favorite.style.color = "white";
    favorite.innerHTML = "Favorited";
}

function addFavorite3 () {
    let favorite = document.getElementById("favoriteBtn3");
    favorite.style.backgroundColor = "red";
    favorite.style.color = "white";
    favorite.innerHTML = "Favorited";
}

function addFavorite4 () {
    let favorite = document.getElementById("favoriteBtn4");
    favorite.style.backgroundColor = "red";
    favorite.style.color = "white";
    favorite.innerHTML = "Favorited";
}

function addFavorite5 () {
    let favorite = document.getElementById("favoriteBtn5");
    favorite.style.backgroundColor = "red";
    favorite.style.color = "white";
    favorite.innerHTML = "Favorited";
}

function addFavorite6 () {
    let favorite = document.getElementById("favoriteBtn6");
    favorite.style.backgroundColor = "red";
    favorite.style.color = "white";
    favorite.innerHTML = "Favorited";
} 

// Ovenstående kode er til dels udarbejdet af GitHub Copilot
// https://www.w3schools.com/js/js_htmldom_html.asp
